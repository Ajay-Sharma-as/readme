#### Hi there 👋, my name is Narender Kumar
###  I am Machine Learning Engineer

Data science enthusiast looking for an opportunity in the field of data science & Machine Learning.
Having a good command on Python,Machine learning, Deep Learning, Data Science, Computer Vision, MySql & Artificial intelligence.

Skills: Data Science/ Machine Learning/ NLP /Computer Vision/ Deep Learning  / MySql/ MongoDB/AmazoneAWS/ HTML / CSS / Java Script 

- 🔭 I’m currently working on Advance Machine Learning Projects 
- 🌱 I’m currently learning Artificial intelligence 
- 👯 I’m looking to collaborate on Machine Learning Projects 


[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='40'>](https://github.com/Narenderbeniwal)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg' alt='linkedin' height='40'>](https://www.linkedin.com/in/narender-kumar-0b774a161/)


<a href='https://docs.github.com/en/developers'><img src='https://raw.githubusercontent.com/acervenky/animated-github-badges/master/assets/devbadge.gif' width='40' height='40'></a> <a href='https://github.com/pricing'><img src='https://raw.githubusercontent.com/acervenky/animated-github-badges/master/assets/pro.gif' width='40' height='40'></a> 

### Languages and Tools:-

[<img align="left" alt="HTML5" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png" />]
[<img align="left" alt="CSS3" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png" />]
[<img align="left" alt="JavaScript" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png" />]


[<img align="left" alt="SQL" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/sql/sql.png" />]
[<img align="left" alt="MySQL" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png" />]
[<img align="left" alt="MongoDB" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mongodb/mongodb.png" />]
[<img align="left" alt="Git" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png" />]
[<img align="left" alt="GitHub" width="26px" src="https://raw.githubusercontent.com/github/explore/78df643247d429f6cc873026c0622819ad797942/topics/github/github.png" />]


<br />

[![trophy](https://github-profile-trophy.vercel.app/?username=Narenderbeniwal)](https://github.com/ryo-ma/github-profile-trophy)

![GitHub stats](https://github-readme-stats.vercel.app/api?username=Narenderbeniwal&show_icons=true)  

![GitHub Activity Graph](https://activity-graph.herokuapp.com/graph?username=Narenderbeniwal)  

![GitHub metrics](https://metrics.lecoq.io/Narenderbeniwal)  

![GitHub streak stats](https://github-readme-streak-stats.herokuapp.com/?user=Narenderbeniwal)  

![Profile views](https://gpvc.arturio.dev/Narenderbeniwal) .
